const http = require("http");
const fs = require("fs");
const path = require("path");
const https = require("https");
const crypto = require("crypto");
const url = require("url");

const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "CHANGE_THIS_PASSWORD";
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
const CHAT_ID = process.env.TELEGRAM_CHAT_ID || "";
const DATA = path.join(__dirname, "data.json");

if (!fs.existsSync(DATA)) fs.writeFileSync(DATA, JSON.stringify({registrations:[]}, null, 2));

function readDB(){ return JSON.parse(fs.readFileSync(DATA,"utf8")); }
function writeDB(db){ fs.writeFileSync(DATA, JSON.stringify(db,null,2)); }
function sendJSON(res, code, data){ res.writeHead(code, {"Content-Type":"application/json; charset=utf-8","Access-Control-Allow-Origin":"*"}); res.end(JSON.stringify(data)); }
function body(req){ return new Promise((resolve,reject)=>{let d="";req.on("data",c=>d+=c);req.on("end",()=>{try{resolve(JSON.parse(d||"{}"))}catch(e){reject(e)}})}); }

function telegram(text){
  if(!BOT_TOKEN || !CHAT_ID) return Promise.resolve(false);
  return new Promise(resolve=>{
    const payload=JSON.stringify({chat_id:CHAT_ID,text});
    const r=https.request({hostname:"api.telegram.org",path:`/bot${BOT_TOKEN}/sendMessage`,method:"POST",headers:{"Content-Type":"application/json","Content-Length":Buffer.byteLength(payload)}},res=>{res.on("data",()=>{});res.on("end",()=>resolve(res.statusCode===200));});
    r.on("error",()=>resolve(false)); r.write(payload); r.end();
  });
}

function auth(req){ return req.headers["x-admin-password"] === ADMIN_PASSWORD; }

const mime={".html":"text/html; charset=utf-8",".js":"text/javascript",".css":"text/css",".json":"application/json",".png":"image/png",".jpg":"image/jpeg",".svg":"image/svg+xml"};

const server=http.createServer(async (req,res)=>{
  const u=url.parse(req.url,true);

  if(req.method==="OPTIONS"){res.writeHead(204,{"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type,x-admin-password"});return res.end();}

  if(req.method==="POST" && u.pathname==="/api/register"){
    try{
      const b=await body(req);
      const reg={id:crypto.randomUUID(),createdAt:new Date().toISOString(),status:"PENDING",...b};
      const db=readDB(); db.registrations.unshift(reg); writeDB(db);
      const players=(b.players||[]).map((p,i)=>`${i+1}. ${p.name} | UID ${p.uid}`).join("\n");
      const msg=`🔥 ZAIDXITA NEW REGISTRATION\n\nTournament: ${b.mode}\nAmount: ₹${b.amount}\nWhatsApp: ${b.whatsapp}\n${players}\n\nUTR: ${b.utr}\n\nStatus: PENDING\nID: ${reg.id}`;
      await telegram(msg);
      sendJSON(res,201,{ok:true,id:reg.id,status:"PENDING",message:"Registration received. Admin verification pending."});
    }catch(e){sendJSON(res,400,{ok:false,error:"Invalid registration data"});}
    return;
  }

  if(req.method==="GET" && u.pathname==="/api/status"){
    const db=readDB(); const r=db.registrations.find(x=>x.id===u.query.id);
    return r?sendJSON(res,200,{ok:true,status:r.status,reason:r.reason||""}):sendJSON(res,404,{ok:false});
  }

  if(req.method==="GET" && u.pathname==="/api/admin/registrations"){
    if(!auth(req)) return sendJSON(res,401,{ok:false,error:"Unauthorized"});
    return sendJSON(res,200,{ok:true,registrations:readDB().registrations});
  }

  if(req.method==="POST" && u.pathname==="/api/admin/status"){
    if(!auth(req)) return sendJSON(res,401,{ok:false,error:"Unauthorized"});
    try{
      const b=await body(req), db=readDB(), r=db.registrations.find(x=>x.id===b.id);
      if(!r) return sendJSON(res,404,{ok:false,error:"Registration not found"});
      if(!["APPROVED","REJECTED"].includes(b.status)) return sendJSON(res,400,{ok:false,error:"Invalid status"});
      r.status=b.status; r.reason=b.reason||""; r.updatedAt=new Date().toISOString(); writeDB(db);
      await telegram(`${b.status==="APPROVED"?"✅":"❌"} ZAIDXITA PAYMENT ${b.status}\n\nTournament: ${r.mode}\nAmount: ₹${r.amount}\nWhatsApp: ${r.whatsapp}\nUTR: ${r.utr}\nID: ${r.id}`);
      sendJSON(res,200,{ok:true,status:r.status});
    }catch(e){sendJSON(res,400,{ok:false,error:"Bad request"});}
    return;
  }

  if(req.method==="GET"){
    let file=u.pathname==="/"?"/index.html":u.pathname;
    if(file==="/admin") file="/admin.html";
    const p=path.join(__dirname,"public",file);
    if(fs.existsSync(p) && fs.statSync(p).isFile()){
      res.writeHead(200,{"Content-Type":mime[path.extname(p)]||"application/octet-stream"}); return res.end(fs.readFileSync(p));
    }
  }
  res.writeHead(404);res.end("Not found");
});
server.listen(PORT,()=>console.log(`Zaidxita running on port ${PORT}`));
