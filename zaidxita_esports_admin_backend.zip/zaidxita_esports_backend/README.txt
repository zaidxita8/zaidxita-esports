ZAIDXITA ESPORTS BACKEND
=========================
यह version registration को backend में save करता है, admin panel देता है और Telegram bot notification भेज सकता है।

चलाने के लिए:
1. Node.js 18+ install करें.
2. Terminal में project folder खोलें.
3. Environment variables सेट करें:
   ADMIN_PASSWORD=अपना मजबूत admin password
   TELEGRAM_BOT_TOKEN=BotFather वाला token
   TELEGRAM_CHAT_ID=आपका Telegram chat id
4. node server.js
5. Browser: http://localhost:3000
6. Admin: http://localhost:3000/admin

IMPORTANT:
- Telegram bot token website HTML में कभी न डालें और किसी को chat में न भेजें.
- अभी payment verification manual है: user UTR देता है, admin approve/reject करता है.
- असली automatic bank/UPI payment verification के लिए payment gateway/merchant API integration चाहिए.
- data.json में registrations save होते हैं; production में database और HTTPS लगाना बेहतर है.
